
## 6872274481.lua (bedwars) Modules we have:
ScytheExploit, CustomPacks, AntiDeath, RemoteTrollage, MelodyExploit, SkidRoaster (yappachino!!), HostPanelExploit (bootycheeks), SemiInstantWin, NoNameTag, RemoveKillFeed

## UNIVERSAL.lua Modules we have:
Watermark, LightingModifications, AnimeImages, AntiCrash, ChatCrasher, AntiLog

## Developers:
@stav (Main Dev, works on core skid-vape), @lyno (making custom profile for me), @qwertyuiisback (MelodyExploit, NetworkBypass).

## Skids: :trollface:
Nebula (skid-bula)

always remember, pasting skid-vxpe without my knowledge is a sin 🙏 

if you need to paste that bad, learn how to code :)
